package zad2;

import java.util.Hashtable;


public interface Wyrazenie {

    int oblicz();

    Wyrazenie pochodna();

}